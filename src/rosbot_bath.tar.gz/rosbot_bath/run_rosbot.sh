#!/bin/bash

roslaunch rosbot_bath rosbot_bath.launch

