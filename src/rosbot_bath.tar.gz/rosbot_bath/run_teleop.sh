#!/bin/bash

roslaunch rosbot_bath rosbot_teleop_bath.launch
