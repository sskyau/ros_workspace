#!/bin/bash

roslaunch rosbot_bath gazebo_only.launch

