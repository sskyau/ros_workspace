#!/bin/bash

roslaunch rosbot_bath rviz_bath.launch

